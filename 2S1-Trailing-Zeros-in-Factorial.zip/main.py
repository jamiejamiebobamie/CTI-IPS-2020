def fast_trailing_zero_factorial(n):
  """ It appears every 5 the number of trailing zeroes increases by one.
  """
  num_zeroes = n // 5
  return num_zeroes
  
# print(fast_trailing_zero_factorial(15))