dependencies = {
  "name": "my_cool_software",
  "version": "1.0.0",
  "dependencies": {
    "xmllib": { 
      "version": "0.2.3",
      "name": "xmllib",
      "dependencies" : {
          "parser": {
            "name": "parser",
            "version": "1.2.1"
          },
          
        }
      },
      "parser": {
        "name": "parser",
        "version": "1.4.6"
       }
    }
}

def flatten_dependencies(JSON_object):
  versions = {}
  def recur(level, dependency_stack):
    while dependency_stack:
      dependency = dependency_stack.pop()
      valid = level.get(dependency,False)
      if valid:
        version = level[dependency].get("version", False)
        if version:
          if dependency not in versions:
            versions[dependency] = [version]
          else:
            if version not in versions[dependency]:
              versions[dependency].append(version)
        valid = level.get(dependency,False)
        if valid:
          new_level = level[dependency].get("dependencies", False)
        if new_level:
          add_to_stack = new_level.keys()
          dependency_stack += add_to_stack
          recur(new_level,dependency_stack)
    for level_object in level:
      if level_object == "dependencies":
        add_to_stack = level["dependencies"].keys()
        dependency_stack += add_to_stack
        recur(level["dependencies"],dependency_stack)
  recur(JSON_object,[])
  JSON = {}
  for dependency_name,version_array in versions.items():
    if len(version_array) > 1:
      for version_num in version_array:
        JSON_key = dependency_name+"@"+version_num
        JSON_value = version_num
        JSON[JSON_key] = JSON_value
    else:
        version_num = version_array[0]
        JSON[dependency_name] = version_num
  
  return JSON
      
        
        
      
JSON = {
  "name": "my_cool_software",
  "version": "1.0.0",
  "dependencies": {
    "xmllib": { 
      "version": "0.2.3",
      "name": "xmllib",
      "dependencies" : {
          "parser": {
            "name": "parser",
            "version": "1.2.1"
          },
          
        }
      },
      "parser": {
        "name": "parser",
        "version": "1.4.6"
       }
    }
}

print(flatten_dependencies(JSON))