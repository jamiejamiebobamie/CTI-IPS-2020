def divide(dividend, divisor):
  if not divisor:
    return "Divide by zero error."
  isNegative = dividend < 0 or divisor < 0
  dividend = abs(dividend)
  divisor = abs(divisor)
  count = -1
  while dividend > 0:
    dividend-=divisor
    count+=1
  return count if not isNegative else 0-count
    
testX = 7
testY = -3
testResult = divide(testX, testY)
print(testResult)