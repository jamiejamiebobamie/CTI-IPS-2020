def strStr(haystack, needle):
  return haystack.find(needle)