def maximize_fun(activities, start, end):
  attending_events = []
  def helper(i,end_time,attending):
    if i == len(activities):
      attending_events.append(attending)
      return
    # don't add the event to attending
    helper(i+1,end_time,attending)
    # add the event to attending if it does not conflict
      # with the current end_time
    if start[i] >= end_time:
      deep_copy = []
      for a in attending:
        deep_copy.append(a)
      deep_copy.append(activities[i])
      end_time = end[i]
      helper(i+1,end_time,deep_copy)
      
  helper(0,float("-inf"),[])
  max_events = []
  for e in attending_events:
    if len(e) >= len(max_events):
      max_events = e
  return max_events
activities = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
start = [0,1,5,6,8,10,11]
end = [2,4,6,8,11,12,20]

print(maximize_fun(activities, start, end))
    
  
  
