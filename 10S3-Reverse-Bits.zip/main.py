def reverse_bits(num):
  count = 0
  reverse = []
  while num or count < 32:
    bit = num%2
    reverse.append(str(bit))
    num//=2
    count+=1
  reverse = "".join(reverse)
  power = 31
  i = 0
  _sum = 0
  while power-i:
    bit = int(reverse[i])
    _sum+=bit*(2**(power-i))
    i+=1
  
  return _sum
    
print(reverse_bits(5))
    