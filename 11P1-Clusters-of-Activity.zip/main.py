# input matrix in example is not valid
  # as dicts can only have one key per value.
  # can have multiple values for one key, but:
    # "4,5": 8,
    # "4,5": 8,
  # ^ will overwrite one another.
def find_center(matrix):
  store_x = {}
  store_y = {}
  for point in matrix.keys():
    coord = point.split(",")
    coord = [int(c) for c in coord]
    x,y = coord
    count = matrix[point]
    if x not in store_x:
      store_x[x] = count
    else:
      store_x[x] += count
    if y not in store_y:
      store_y[y] = count
    else:
      store_y[y] += count
  max_x = float("-inf")
  max_x_val = float("-inf")
  for x,count in store_x.items():
    if count > max_x_val:
      max_x = x
      max_x_val = count
  max_y = float("-inf")
  max_y_val = float("-inf")
  for y,count in store_y.items():
    if count > max_y_val:
      max_y = y
      max_y_val = count
  
  return str(max_x)+","+str(max_y)

reported_outbreak = {
  "5,5": 10,
  "5,6": 8,
  "5,4": 8,
  "4,5": 8,
  "4,5": 8,
  "4,6": 8,
  "6,6": 7,
  "6,5": 8,
  "4,4": 8,
  "3,4": 4,
  "3,3": 2,
  "6,7": 2
}

print(find_center(reported_outbreak))