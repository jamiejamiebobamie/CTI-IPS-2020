def add(a,b):
  return a + b
# subtract six from four
def subtract(a,b):
  return b - a
def multiplication(a,b):
  return a * b
def division(a,b):
  return a//b

def nlp_calculator(statement):
  translator = {
  "add": add,
  "subtract":subtract,
  "divide": division,
  "multiply":multiplication,
  "zero":0,
   "one":1,
   "two":2,
   "three":3,
   "four":4,
   "five":5,
   "six":6,
   "seven":7,
   "eight":8,
   "nine":9,
   "ten":10,
   "eleven":11,
   "twelve":12,
   "thirteen":13,
   "fourteen":14,
   "fifteen":15,
   "sixteen":16,
   "seventeen":17,
   "eighteen":18,
   "nineteen":19,
   "twenty":20,
   "thirty":30,
   "fourty":40,
   "fifty":50,
   "sixty":60,
   "seventy":70,
   "eighty":80,
   "ninety":90,
  }

  words = statement.split(" ")
  print(words)
  command = translator[words[0]]
  a = translator[words[1]]
  b = translator[words[3]]
  
  answer_num = command(a,b)
  # answer_num_str = str(answer_num)
  output = []
  pow = 0
  while answer_num:
    digit = answer_num % 10
    digit*=10**pow
    for key,val in translator.items():
      if digit == val:
        output.append(key)
    answer_num//=10
    pow+=1
  if len(output)>1:
    a = output.pop()
    b = output.pop()
    added_output = add(a,b)
    print(added_output)
    for key,val in translator.items():
      if output == val:
        return output
  # return output
    


print(nlp_calculator("multiply four by four"))



