den = [10000, 5000, 1000, 500, 100, 50, 25, 10, 5, 1]

# greedy algorithm.
# we want to add the biggest coin from den at each interval

def get_change(N):
  change = []
  i = 0
  while N:
    if i > len(den)-1:
      i = 0
    elif N>=den[i]:
      change.append(den[i])
      N-=den[i]
    else:
      i+=1
  return change

print(get_change(370))