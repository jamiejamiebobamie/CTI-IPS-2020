def sentiment_scores(sentiments, texts):
  sentiment_scores = []
  for sentence in texts:
    words = sentence.replace(".","").replace("!","").replace(",","").replace("?","").split(" ")
    sentiment_score = []
    for word in words:
      if word in sentiments:
        sentiment_score.append(sentiments[word])
    sentiment_scores.append(sum(sentiment_score))
  return sentiment_scores