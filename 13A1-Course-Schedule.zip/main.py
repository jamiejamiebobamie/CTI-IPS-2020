# need to store circular dependencies

def can_finish(num_courses, prerequisites):
  prereq_lookup = {}
  results = []
  def helper(curr, count):
    if count >= num_courses:
      results.append(False)
      return
    current_course = curr
    while current_course != None and count < num_courses:
      prereq_courses_array = prereq_lookup.get(current_course,False)
      print(curr, prereq_courses_array)
      if prereq_courses_array:
        for course in prereq_courses_array:
          helper(course, count+1)
      else:
        current_course = None
      count+=1
    if current_course == None:
      results.append(True)
    return 
    
  for course,prereq in prerequisites:
    if course not in prereq_lookup:
      prereq_lookup[course] = [prereq]
    else:
      prereq_lookup[course].append(prereq)
  current_course = prerequisites[0][0]
  count = 0
  helper(current_course, count)
  print(prereq_lookup)
  return True if all(results) else False
  

# print(can_finish(2, [[1,0],[0,1]] ) ) # False
# print(can_finish(4, [[1,0],[1,2],[2,3],[3,1]] ) ) # should be False