# I believe there is a trick with xor that can compute the answer
  # in constant time, but I couldn't find it after a quick google search.
def count_set_bits(num):
  count = 0
  while num:
    bit = num % 2
    if bit:
      count+=1
    num//=2
  return count

# print(count_set_bits(7))