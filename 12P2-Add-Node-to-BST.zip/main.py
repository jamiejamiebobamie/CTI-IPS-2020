class Node:
  def __init__(self,data):
    self.data = data
    self.left = None
    self.right = None


class Tree:
  def __init__(self):
    self.root = None

  def print_bfs(self):
    if not self.root:
      return

    queue = [self.root]

    while len(queue) > 0:
      current_node = queue.pop(0)
      print(current_node.data)
      if current_node.left:
        queue.append(current_node.left)
      if current_node.right:
        queue.append(current_node.right)

  def in_order_traversal(self):
    nodes = []
    def dfs(node):
      if node:
        
        dfs(node.left)
        nodes.append(node.data)
        dfs(node.right)

        
    dfs(self.root)
    return nodes
    
  def add(self,node):
    def helper(BN,parent,wentRight):
      if BN:
        if BN.data < node.data:
          helper(BN.right,BN,True)
        else:
          helper(BN.left,BN,False)
      else:
        if wentRight:
          parent.right = node
        else:
          parent.left = node
    if self.root:
      if self.root.data < node.data:
        helper(self.root.right,self.root,True)
      else:
        helper(self.root.left,self.root,False)
    else:
      self.root = node

      
      