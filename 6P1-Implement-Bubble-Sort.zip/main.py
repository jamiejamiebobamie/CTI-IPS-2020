def bubble_sort_swaps(nums):
  count = 0
  isSorted = False
  while not isSorted:
    isSorted = True
    for i in range(len(nums)-1):
      if nums[i] > nums[i+1]:
        nums[i], nums[i+1] = nums[i+1], nums[i]
        count+=1
        isSorted = False
  return count
        
        

