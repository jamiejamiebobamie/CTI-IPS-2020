def hammingDistance(x, y):
  new_word = x ^ y
  count = 0
  while new_word:
    bit = new_word % 2
    if bit:
      count+=1
    new_word//=2
  
  return count
      

testX = 10
testY = 11
testResult = hammingDistance(testX, testY)
print(testResult)