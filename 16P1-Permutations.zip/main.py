# https://en.wikipedia.org/wiki/Heap%27s_algorithm#cite_note-3

# procedure generate(k : integer, A : array of any):
#     if k = 1 then
#         output(A)
#     else
#         for i := 0; i < k; i += 1 do
#             generate(k - 1, A)
#             if k is even then
#                 swap(A[i], A[k-1])
#             else
#                 swap(A[0], A[k-1]) 
#             end if

#         end for
#     end if
    
def get_permutations(input_list):
  perms = list()
  def helper(k,arr):
    if k == 1:
      perms.append(arr)
      return
    else:
      for i in range(k):
        
        deep_copy = []
        # print(arr)
        for a in arr:
          deep_copy.append(a)
          
        helper(k-1,deep_copy)
        # if i < k - 1:
        if not k % 2:
          arr[i], arr[k-1] = arr[k-1], arr[i]
        else:
          arr[0], arr[k-1] = arr[k-1], arr[0]

        
  helper(len(input_list),input_list)
  print(len(perms))
  count = 0
  for p in perms:
    helper(len(p),p)
    if count == len(perms):
      break
    count+=1
  unique = set([tuple(p) for p in perms])
  perms = [list(p) for p in unique]
  perms.sort()
  return perms
  
    
  
    
print(get_permutations([1,2,3]))
    
    
    
    