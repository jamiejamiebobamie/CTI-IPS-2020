class SocialGraph:
  def __init__(self):
    self.members = {}


  def add_node(self,node):
    self.members[node] = set()


  def add_edge(self,node_a,node_b):
    self.members[node_a].add(node_b)
    self.members[node_b].add(node_a)
    
  def subgraph(self, root):
    to_visit = [root]

    visited = set()

    while len(to_visit) > 0:
      node = to_visit.pop(0)
      if node not in visited:
        
        visited.add(node)

        for neighbor in self.members[node]:
          to_visit.append(neighbor)
    return visited
    
  def suggest_friends(self, me):
    subgraph = self.subgraph(me)
    histo = {}
    for friend in subgraph:
      for neighbor in self.members[friend]:
        if neighbor not in histo:
          histo[neighbor] = 1
        else:
          histo[neighbor] += 1
    max_count = 0
    suggestions = set()
    me_neighbors = set()
    for neighbor in self.members[me]:
      me_neighbors.add(neighbor)
    for friend in histo:
      # I'm enjoying this interview course, but the wording of
        # "all the friends with the highest count" is a bit unclear.
      if friend not in me_neighbors and friend != me:
        if (max_count == histo[friend] or max_count == histo[friend]+1) and histo[friend] != 1:
          suggestions.add(friend)
        elif max_count < histo[friend]:
          max_count = histo[friend]
          suggestions = set()
          suggestions.add(friend)
    return suggestions

graph = SocialGraph()

## Friend Group 1
graph.add_node('Alice')
graph.add_node('Bob')
graph.add_node('Carol')
graph.add_node('Dave')
graph.add_node('Eve')
graph.add_node('Faythe')
graph.add_node('Grace')

graph.add_edge('Alice', 'Bob')
graph.add_edge('Alice', 'Carol')
graph.add_edge('Alice', 'Dave')
graph.add_edge('Bob', 'Dave')
graph.add_edge('Carol', 'Dave')
graph.add_edge('Alice', 'Eve')
graph.add_edge('Eve', 'Grace')
graph.add_edge('Eve', 'Bob')
graph.add_edge('Faythe', 'Eve')
graph.add_edge('Dave', 'Faythe')
graph.add_edge('Grace', 'Faythe')
print(graph.suggest_friends("Faythe"))