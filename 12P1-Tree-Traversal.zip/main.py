class Node:
  def __init__(self, data=None):
    self.data = data
    self.left = None
    self.right = None
    
class LLNode:
  def __init__(self, data=None):
    self.data = data
    self.next = None
    
class LL:
  def __init__(self, BN=None):
    data = BN.data
    node = LLNode(data)
    self.head = node
    self.tail = node
  
  def append_children(self,left_BN=None,right_BN=None):
    if left_BN != None and right_BN != None:
      left = LLNode(left_BN.data)
      right = LLNode(right_BN.data)
      self.tail.next = left
      left.next = right
      self.tail = right
    elif left_BN != None and right_BN == None:
      left = LLNode(left_BN.data)
      self.tail.next = left
      self.tail = left
    elif left_BN == None and right_BN != None:
      right = LLNode(right_BN.data)
      self.tail.next = right
      self.tail = right

  def get_list_of_data(self):
    node = self.head
    return_list = []
    while node:
      return_list.append(node.data)
      node = node.next
    return return_list
  
class Tree:
  def __init__(self):
    self.root = None
    
  def level_order_traversal(self):
    def helper(node):
      if node:
        ll.append_children(node.left,node.right)
        helper(node.left)
        helper(node.right)
    ll = LL(self.root)
    helper(self.root)
    return ll.get_list_of_data()
    
  def pre_order_traversal(self):
    return_list = []
    def helper(node):
      if node:
        return_list.append(node.data)
        helper(node.left)
        helper(node.right)
      return
    helper(self.root)
    # return the tree as a list in a pre-order sequence (dfs)
    return return_list
    
  def in_order_traversal(self):
    return_list = []
    def helper(node):
      if node:
        helper(node.left)
        return_list.append(node.data)
        helper(node.right)
      return
    helper(self.root)
    return return_list
    
  def post_order_traversal(self):
    return_list = []
    def helper(node):
      if node:
        helper(node.left)
        helper(node.right)
        return_list.append(node.data)
      return
    helper(self.root)
    return return_list

# tree= Tree()
# tree.root = Node(9)
# tree.root.left = Node(5)
# tree.root.right = Node(11)
# tree.root.left.left = Node(3)
# tree.root.left.right = Node(7)

# print(tree.level_order_traversal())