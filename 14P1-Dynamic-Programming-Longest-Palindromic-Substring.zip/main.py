## Given this recursive solution to the longestPalindrome problem,
## Start by writing out the recursive tree of function calls to understand the problem
## then, think about how you might turn this into an iterative solution.
def longestPalindrome(s):
  def f(start, length):
    
    ## Base Case- segments of length 1 are palindromes
    if length < 2 and start > 0:
        length_one = f(start - 1, 1) 
    else:
        length_one = (-1,-1)
    
    ## Check to see if the letter at start-1 is the same as start
    if length < 2 and start > 0 and s[start-1] == s[start]:
        length_two = f(start - 1, 2) 
    else:
        length_two = (-1, -1)
    
    ## Check to see if the beginning of the substring and end of substring are same
    if start > 0 and start + length < len(s) and s[start-1] == s[start + length]:
        expanded_current_slice = f(start - 1, length + 2)
    else:
        expanded_current_slice = (-1, -1)
    
    
    current_slice = (length, start)
    
    return max(
        # base cases that iterate
        length_one,
        length_two,
        # a larger palindrome than this one
        expanded_current_slice,
        # this one
        current_slice
    )

  (length_of_palindrome, start_index) = f(len(s) - 1, 1)
  return s[start_index:start_index+length_of_palindrome]

longestPalindrome("abcbd")